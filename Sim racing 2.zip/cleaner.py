"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/cleaner.py

Signal cleaning pipeline:
  - rolling mean smoothing
  - spike / outlier removal
  - NaN interpolation
  - distance normalisation
  - signal clamping to physical bounds
"""

import pandas as pd
import numpy as np
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# ─── Physical bounds for hard clipping ────────────────────────────────────────
SIGNAL_BOUNDS: dict[str, tuple[float, float]] = {
    "speed":    (0.0,   450.0),   # km/h  — covers any current race car
    "throttle": (0.0,   1.0),     # 0–1 normalised
    "brake":    (0.0,   1.0),
    "rpm":      (0.0,   20_000.0),
    "steering": (-1.0,  1.0),     # normalised −1 … +1
    "gear":     (0.0,   10.0),
    "tire_temp":(0.0,   200.0),   # °C
    "tire_slip":(0.0,   1.0),
    "fuel":     (0.0,   200.0),   # litres
}

# Default smoothing window sizes (samples) per signal
DEFAULT_WINDOWS: dict[str, int] = {
    "speed":    5,
    "throttle": 3,
    "brake":    3,
    "steering": 7,
    "rpm":      5,
    "tire_temp":11,
    "tire_slip":5,
}


# ─── Main pipeline ────────────────────────────────────────────────────────────

def clean_telemetry(
    df: pd.DataFrame,
    smooth_signals: Optional[list[str]] = None,
    spike_zscore_threshold: float = 4.0,
    interpolation_method: str = "linear",
    normalise_distance: bool = True,
) -> pd.DataFrame:
    """
    Full signal-cleaning pipeline.

    Parameters
    ----------
    df                      : Raw telemetry DataFrame (output of loader).
    smooth_signals          : Columns to smooth.  None → auto-detect from
                              DEFAULT_WINDOWS keys present in df.
    spike_zscore_threshold  : Z-score above which a sample is flagged as a
                              spike and replaced with NaN before interpolation.
    interpolation_method    : Pandas interpolation method for NaN fill.
    normalise_distance      : Re-scale distance so each lap starts at 0 m.

    Returns
    -------
    pd.DataFrame  — cleaned copy of the input, with a '__cleaned' suffix on
                    columns that were modified.
    """
    df = df.copy()

    # ── 1. Hard-clip to physical bounds ────────────────────────────────────
    df = _clip_to_bounds(df)

    # ── 2. Remove / interpolate NaNs ───────────────────────────────────────
    df = _fill_nans(df, method=interpolation_method)

    # ── 3. Spike removal ───────────────────────────────────────────────────
    df = _remove_spikes(df, threshold=spike_zscore_threshold,
                         method=interpolation_method)

    # ── 4. Smoothing ───────────────────────────────────────────────────────
    if smooth_signals is None:
        smooth_signals = [c for c in DEFAULT_WINDOWS if c in df.columns]
    df = _smooth_signals(df, smooth_signals)

    # ── 5. Normalise distance ──────────────────────────────────────────────
    if normalise_distance and "distance" in df.columns:
        df = _normalise_distance(df)

    # ── 6. Normalise throttle / brake to 0-1 if they appear to be 0-100 ──
    for col in ("throttle", "brake"):
        if col in df.columns and df[col].max() > 1.5:
            logger.info(f"Normalising '{col}' from 0-100 to 0-1 range.")
            df[col] = df[col] / 100.0

    logger.info("Signal cleaning complete.")
    return df


# ─── Step implementations ─────────────────────────────────────────────────────

def _clip_to_bounds(df: pd.DataFrame) -> pd.DataFrame:
    for col, (lo, hi) in SIGNAL_BOUNDS.items():
        if col in df.columns:
            n_clipped = ((df[col] < lo) | (df[col] > hi)).sum()
            if n_clipped:
                logger.debug(f"Clipping {n_clipped} values in '{col}' to [{lo}, {hi}].")
            df[col] = df[col].clip(lo, hi)
    return df


def _fill_nans(df: pd.DataFrame, method: str = "linear") -> pd.DataFrame:
    numeric = df.select_dtypes(include=np.number).columns
    total_nan = df[numeric].isna().sum().sum()
    if total_nan:
        logger.info(f"Interpolating {total_nan} NaN values (method='{method}').")
        df[numeric] = (
            df[numeric]
            .interpolate(method=method, limit_direction="both")
            .ffill()
            .bfill()
        )
    return df


def _remove_spikes(
    df: pd.DataFrame,
    threshold: float,
    method: str,
    cols: Optional[list[str]] = None,
) -> pd.DataFrame:
    """
    Replace values whose z-score (within a rolling 30-sample window) exceeds
    `threshold` with NaN, then re-interpolate.
    """
    if cols is None:
        cols = [c for c in ["speed", "throttle", "brake", "rpm", "steering"]
                if c in df.columns]

    total_spikes = 0
    for col in cols:
        s = df[col].copy()
        roll_mean = s.rolling(30, center=True, min_periods=1).mean()
        roll_std  = s.rolling(30, center=True, min_periods=1).std().replace(0, np.nan)
        z = (s - roll_mean).abs() / roll_std
        spikes = z > threshold
        count  = spikes.sum()
        if count:
            logger.debug(f"Removing {count} spike(s) from '{col}'.")
            df.loc[spikes, col] = np.nan
            total_spikes += count

    if total_spikes:
        numeric = df.select_dtypes(include=np.number).columns
        df[numeric] = (
            df[numeric]
            .interpolate(method=method, limit_direction="both")
            .ffill().bfill()
        )
        logger.info(f"Spike removal: {total_spikes} total spikes replaced.")

    return df


def _smooth_signals(df: pd.DataFrame, signals: list[str]) -> pd.DataFrame:
    for col in signals:
        if col not in df.columns:
            continue
        win = DEFAULT_WINDOWS.get(col, 5)
        df[col] = (
            df[col]
            .rolling(window=win, center=True, min_periods=1)
            .mean()
        )
        logger.debug(f"Smoothed '{col}' with window={win}.")
    return df


def _normalise_distance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Per-lap distance normalisation: distance resets to 0 at each lap start.
    """
    if "lap_number" in df.columns:
        df["distance"] = df.groupby("lap_number")["distance"].transform(
            lambda x: x - x.iloc[0]
        )
    else:
        df["distance"] = df["distance"] - df["distance"].iloc[0]
    return df


# ─── Standalone helpers ───────────────────────────────────────────────────────

def compute_derivatives(df: pd.DataFrame) -> pd.DataFrame:
    """
    Append first-order time derivatives for key signals.
    Useful for detecting brake onset, throttle ramp rate, etc.

    Added columns: d_speed, d_throttle, d_brake
    """
    dt = df["time"].diff().replace(0, np.nan)
    for col in ("speed", "throttle", "brake"):
        if col in df.columns:
            df[f"d_{col}"] = df[col].diff() / dt
    return df


def flag_coasting(
    df: pd.DataFrame,
    throttle_threshold: float = 0.05,
    brake_threshold: float = 0.05,
) -> pd.DataFrame:
    """
    Add a boolean 'coasting' column where neither throttle nor brake is applied.
    """
    if "throttle" in df.columns and "brake" in df.columns:
        df["coasting"] = (
            (df["throttle"] < throttle_threshold) &
            (df["brake"]    < brake_threshold)
        )
    return df
