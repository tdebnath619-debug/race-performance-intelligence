"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/loader.py

Loads and standardizes raw telemetry CSV files from:
- Assetto Corsa
- iRacing
- Assetto Corsa Competizione (ACC)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

# ─── Column name aliases ───────────────────────────────────────────────────────
# Maps platform-specific column names → internal standard names
COLUMN_ALIASES: dict[str, str] = {
    # Time
    "timestamp": "time",
    "time_s": "time",
    "elapsed": "time",
    # Distance
    "dist": "distance",
    "track_position": "distance",
    "lap_dist": "distance",
    # Speed
    "speed_kmh": "speed",
    "velocity": "speed",
    "car_speed": "speed",
    # Throttle
    "gas": "throttle",
    "throttle_input": "throttle",
    "throttle_pct": "throttle",
    # Brake
    "brake_input": "brake",
    "brake_pct": "brake",
    "braking": "brake",
    # Gear
    "current_gear": "gear",
    # RPM
    "engine_rpm": "rpm",
    # Steering
    "steer": "steering",
    "steer_angle": "steering",
    "steering_wheel": "steering",
    # Lap time
    "current_lap_time": "lap_time",
    "laptime": "lap_time",
}

REQUIRED_COLUMNS: list[str] = ["time", "speed"]

OPTIONAL_COLUMNS: list[str] = [
    "distance", "throttle", "brake", "gear",
    "rpm", "steering", "lap_time",
    "tire_temp", "tire_slip", "fuel",
]


# ─── Loader ───────────────────────────────────────────────────────────────────

def load_telemetry(
    file_path: str | Path,
    lap_number: Optional[int] = None,
    resample_hz: Optional[float] = None,
) -> pd.DataFrame:
    """
    Load a telemetry CSV file and return a clean, standardized DataFrame.

    Parameters
    ----------
    file_path   : Path to the telemetry CSV file.
    lap_number  : If the file contains multiple laps, filter to this lap index
                  (0-based).  None → return all laps.
    resample_hz : Optional target sample rate in Hz.  Resamples the data to a
                  uniform time grid when provided.

    Returns
    -------
    pd.DataFrame  with standardized column names and SI units.
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"Telemetry file not found: {file_path}")

    logger.info(f"Loading telemetry: {file_path.name}")
    df = pd.read_csv(file_path)

    # ── 1. Normalize column names ──────────────────────────────────────────
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")
    df = df.rename(columns=COLUMN_ALIASES)

    # ── 2. Validate required columns ──────────────────────────────────────
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"Required columns missing from telemetry file: {missing}\n"
            f"Available columns: {list(df.columns)}"
        )

    # ── 3. Convert time units → seconds ───────────────────────────────────
    df = _normalise_time(df)

    # ── 4. Compute cumulative distance if missing ──────────────────────────
    if "distance" not in df.columns:
        logger.warning("'distance' column missing — computing from speed × Δt.")
        df = _compute_distance(df)

    # ── 5. Lap number handling ─────────────────────────────────────────────
    if "lap_number" not in df.columns:
        df = _infer_lap_number(df)

    if lap_number is not None:
        available = sorted(df["lap_number"].unique())
        if lap_number not in available:
            raise ValueError(
                f"Lap {lap_number} not found. Available laps: {available}"
            )
        df = df[df["lap_number"] == lap_number].reset_index(drop=True)
        logger.info(f"Filtered to lap {lap_number} — {len(df)} samples.")

    # ── 6. Optional resampling ─────────────────────────────────────────────
    if resample_hz is not None:
        df = _resample(df, resample_hz)

    # ── 7. Drop fully-empty optional columns ──────────────────────────────
    df = df.dropna(axis=1, how="all")

    # ── 8. Sort by time ───────────────────────────────────────────────────
    df = df.sort_values("time").reset_index(drop=True)

    logger.info(
        f"Telemetry loaded: {len(df)} samples | "
        f"Columns: {list(df.columns)} | "
        f"Laps: {sorted(df['lap_number'].unique())}"
    )
    return df


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _normalise_time(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure 'time' column is in seconds (float)."""
    t = df["time"]
    if t.dtype == object:
        # Try HH:MM:SS.sss or MM:SS.sss format
        try:
            df["time"] = pd.to_timedelta(t).dt.total_seconds()
            return df
        except Exception:
            pass
    # If values appear to be in milliseconds (max > 10 000 s is suspicious)
    if t.max() > 10_000 and t.min() >= 0:
        logger.info("Time values appear to be in milliseconds — converting.")
        df["time"] = t / 1_000.0
    return df


def _compute_distance(df: pd.DataFrame) -> pd.DataFrame:
    """Estimate cumulative track distance (m) from speed (km/h) and time (s)."""
    speed_ms = df["speed"] / 3.6            # km/h → m/s
    dt = df["time"].diff().fillna(0)
    df["distance"] = (speed_ms * dt).cumsum()
    return df


def _infer_lap_number(df: pd.DataFrame) -> pd.DataFrame:
    """
    Infer lap boundaries from distance resets or lap_time resets.
    Assigns an integer lap_number column (0-based).
    """
    if "lap_time" in df.columns:
        # Detect lap reset when lap_time decreases significantly
        reset = df["lap_time"].diff() < -5.0
    else:
        # Detect distance reset
        reset = df["distance"].diff() < -50.0

    df["lap_number"] = reset.cumsum().astype(int)
    return df


def _resample(df: pd.DataFrame, hz: float) -> pd.DataFrame:
    """Resample telemetry to a uniform time grid at the given sample rate."""
    t_start = df["time"].min()
    t_end   = df["time"].max()
    t_new   = np.arange(t_start, t_end, 1.0 / hz)

    numeric_cols = df.select_dtypes(include=np.number).columns
    resampled = {}
    for col in numeric_cols:
        resampled[col] = np.interp(t_new, df["time"], df[col])

    logger.info(f"Resampled to {hz} Hz — {len(t_new)} samples.")
    return pd.DataFrame(resampled)


# ─── Utilities ────────────────────────────────────────────────────────────────

def list_laps(df: pd.DataFrame) -> pd.DataFrame:
    """
    Return a summary DataFrame with one row per lap.

    Columns: lap_number, samples, duration_s, distance_m, max_speed_kmh
    """
    rows = []
    for lap, grp in df.groupby("lap_number"):
        rows.append({
            "lap_number":    lap,
            "samples":       len(grp),
            "duration_s":    round(grp["time"].max() - grp["time"].min(), 3),
            "distance_m":    round(grp["distance"].max() - grp["distance"].min(), 1),
            "max_speed_kmh": round(grp["speed"].max(), 1),
        })
    return pd.DataFrame(rows)


def save_processed(df: pd.DataFrame, out_dir: str | Path = "data/processed",
                   stem: str = "telemetry") -> Path:
    """Save a processed DataFrame to the processed data folder."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{stem}_processed.csv"
    df.to_csv(out_path, index=False)
    logger.info(f"Processed telemetry saved → {out_path}")
    return out_path
