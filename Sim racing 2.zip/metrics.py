"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/metrics.py

Compute per-corner and per-lap performance indicators.

Per-corner metrics
------------------
  entry_speed         km/h  — speed at braking onset
  min_speed           km/h  — speed at apex
  exit_speed          km/h  — speed at corner exit
  brake_start_dist    m     — distance at which braking begins
  throttle_pickup_dist m    — distance at which driver opens throttle post-apex
  brake_pressure_max  0-1   — peak brake application
  throttle_ramp_rate  1/s   — rate of throttle increase during exit
  corner_time_s       s     — total time from entry to exit
  v_loss              km/h  — entry_speed − min_speed  (braking efficiency proxy)
  v_recovery          km/h  — exit_speed − min_speed   (traction / exit quality)

Per-lap metrics
---------------
  lap_time_s
  avg_speed_kmh
  max_speed_kmh
  total_brake_time_s
  total_coasting_time_s
  avg_throttle_pct
  top_gear
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, asdict, field
from typing import Optional
import logging

from .segmentation import Corner, extract_corner_slice

logger = logging.getLogger(__name__)


# ─── Data structures ─────────────────────────────────────────────────────────

@dataclass
class CornerMetrics:
    corner_id:              int
    entry_speed:            float        # km/h
    min_speed:              float        # km/h
    exit_speed:             float        # km/h
    brake_start_dist:       float        # m
    throttle_pickup_dist:   float        # m
    brake_pressure_max:     float        # 0-1
    throttle_ramp_rate:     float        # s⁻¹ (Δthrottle/Δtime during exit)
    corner_time_s:          float        # s
    v_loss:                 float = field(init=False)
    v_recovery:             float = field(init=False)
    late_braking_score:     float = 0.0  # 0–100 (higher = later braking)
    exit_quality_score:     float = 0.0  # 0–100 (higher = better exit)

    def __post_init__(self):
        self.v_loss     = round(self.entry_speed - self.min_speed, 2)
        self.v_recovery = round(self.exit_speed  - self.min_speed, 2)

    def to_dict(self) -> dict:
        return asdict(self)

    def __repr__(self):
        return (
            f"Corner {self.corner_id:2d} | "
            f"Entry {self.entry_speed:6.1f} km/h | "
            f"Apex {self.min_speed:6.1f} km/h | "
            f"Exit {self.exit_speed:6.1f} km/h | "
            f"Δv_loss={self.v_loss:.1f} | "
            f"time={self.corner_time_s:.3f} s"
        )


@dataclass
class LapMetrics:
    lap_id:                int
    lap_time_s:            float
    avg_speed_kmh:         float
    max_speed_kmh:         float
    total_brake_time_s:    float
    total_coasting_time_s: float
    avg_throttle_pct:      float
    top_gear:              int
    n_corners:             int
    corner_metrics:        list[CornerMetrics] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["corner_metrics"] = [c.to_dict() for c in self.corner_metrics]
        return d


# ─── Main entry point ─────────────────────────────────────────────────────────

def compute_lap_metrics(
    df: pd.DataFrame,
    corners: list[Corner],
    lap_id: int = 0,
    throttle_threshold: float = 0.10,
    brake_threshold:    float = 0.05,
) -> LapMetrics:
    """
    Compute full lap + per-corner metrics.

    Parameters
    ----------
    df      : Cleaned, single-lap telemetry DataFrame.
    corners : Detected corners (output of segmentation.segment_corners).
    lap_id  : Identifier for the lap (used in reports).

    Returns
    -------
    LapMetrics object containing per-lap and per-corner metrics.
    """
    # ── Lap-level metrics ──────────────────────────────────────────────────
    dt = df["time"].diff().fillna(0)
    lap_time_s = float(df["time"].max() - df["time"].min())

    has_throttle = "throttle" in df.columns
    has_brake    = "brake"    in df.columns
    has_gear     = "gear"     in df.columns

    total_brake_time_s = float(
        dt[df["brake"] > brake_threshold].sum() if has_brake else 0.0
    )
    total_coasting_time_s = float(
        dt[
            (df.get("throttle", pd.Series(dtype=float)) < throttle_threshold) &
            (df.get("brake",    pd.Series(dtype=float)) < brake_threshold)
        ].sum() if (has_throttle and has_brake) else 0.0
    )
    avg_throttle_pct = float(
        df["throttle"].mean() * 100 if has_throttle else 0.0
    )
    top_gear = int(df["gear"].max()) if has_gear else 0

    # ── Per-corner metrics ─────────────────────────────────────────────────
    corner_metrics = []
    for corner in corners:
        cm = _compute_corner_metrics(df, corner, throttle_threshold, brake_threshold)
        if cm is not None:
            corner_metrics.append(cm)

    lap = LapMetrics(
        lap_id                = lap_id,
        lap_time_s            = round(lap_time_s, 3),
        avg_speed_kmh         = round(float(df["speed"].mean()), 2),
        max_speed_kmh         = round(float(df["speed"].max()),  2),
        total_brake_time_s    = round(total_brake_time_s, 3),
        total_coasting_time_s = round(total_coasting_time_s, 3),
        avg_throttle_pct      = round(avg_throttle_pct, 2),
        top_gear              = top_gear,
        n_corners             = len(corner_metrics),
        corner_metrics        = corner_metrics,
    )

    logger.info(
        f"Lap {lap_id}: {lap.lap_time_s:.3f} s | "
        f"avg {lap.avg_speed_kmh:.1f} km/h | "
        f"corners: {lap.n_corners}"
    )
    return lap


# ─── Per-corner computation ───────────────────────────────────────────────────

def _compute_corner_metrics(
    df: pd.DataFrame,
    corner: Corner,
    throttle_threshold: float,
    brake_threshold: float,
) -> Optional[CornerMetrics]:
    """Extract metric values for a single corner."""
    try:
        entry_row = df.iloc[corner.entry_idx]
        apex_row  = df.iloc[corner.apex_idx]
        exit_row  = df.iloc[corner.exit_idx]

        # ── Speeds ────────────────────────────────────────────────────────
        entry_speed = round(float(entry_row["speed"]), 2)
        min_speed   = round(float(apex_row["speed"]),  2)
        exit_speed  = round(float(exit_row["speed"]),  2)

        # ── Braking ───────────────────────────────────────────────────────
        brake_start_dist = round(float(entry_row["distance"]), 1)
        brake_pressure_max = 0.0
        if "brake" in df.columns:
            brake_slice = df.iloc[corner.entry_idx:corner.apex_idx]["brake"]
            brake_pressure_max = round(float(brake_slice.max()), 3)

        # ── Throttle pickup ───────────────────────────────────────────────
        throttle_pickup_dist = round(float(apex_row["distance"]), 1)
        throttle_ramp_rate   = 0.0
        if "throttle" in df.columns:
            exit_slice = df.iloc[corner.apex_idx:corner.exit_idx]
            above = exit_slice[exit_slice["throttle"] > throttle_threshold]
            if not above.empty:
                throttle_pickup_dist = round(float(above.iloc[0]["distance"]), 1)
                # Ramp rate: Δthrottle / Δtime over first 20 samples of exit
                ramp_window = above.iloc[:20]
                if len(ramp_window) > 1:
                    dT = ramp_window["throttle"].iloc[-1] - ramp_window["throttle"].iloc[0]
                    dt = ramp_window["time"].iloc[-1]    - ramp_window["time"].iloc[0]
                    throttle_ramp_rate = round(float(dT / dt) if dt > 0 else 0.0, 4)

        # ── Derived scores (0-100, simple heuristics) ─────────────────────
        # Late braking: shorter braking zone → higher score
        braking_zone_m = float(apex_row["distance"]) - float(entry_row["distance"])
        # Normalise: assume max braking zone ≈ 150 m
        late_braking_score = round(max(0.0, 100.0 * (1.0 - braking_zone_m / 150.0)), 1)

        # Exit quality: ratio of exit speed to entry speed (capped at 100)
        exit_quality_score = round(
            min(100.0, 100.0 * exit_speed / max(entry_speed, 1.0)), 1
        )

        return CornerMetrics(
            corner_id            = corner.corner_id,
            entry_speed          = entry_speed,
            min_speed            = min_speed,
            exit_speed           = exit_speed,
            brake_start_dist     = brake_start_dist,
            throttle_pickup_dist = throttle_pickup_dist,
            brake_pressure_max   = brake_pressure_max,
            throttle_ramp_rate   = throttle_ramp_rate,
            corner_time_s        = corner.corner_time_s,
            late_braking_score   = late_braking_score,
            exit_quality_score   = exit_quality_score,
        )

    except Exception as exc:
        logger.warning(f"Could not compute metrics for corner {corner.corner_id}: {exc}")
        return None


# ─── Utility ─────────────────────────────────────────────────────────────────

def metrics_to_dataframe(lap_metrics: LapMetrics) -> pd.DataFrame:
    """Flatten corner metrics into a tidy DataFrame."""
    return pd.DataFrame([c.to_dict() for c in lap_metrics.corner_metrics])


def print_lap_summary(lap_metrics: LapMetrics) -> None:
    """Human-readable console summary of a lap."""
    print("=" * 65)
    print(f"  LAP {lap_metrics.lap_id}  —  {lap_metrics.lap_time_s:.3f} s")
    print("=" * 65)
    print(f"  Avg speed   : {lap_metrics.avg_speed_kmh:.1f} km/h")
    print(f"  Max speed   : {lap_metrics.max_speed_kmh:.1f} km/h")
    print(f"  Brake time  : {lap_metrics.total_brake_time_s:.2f} s")
    print(f"  Coast time  : {lap_metrics.total_coasting_time_s:.2f} s")
    print(f"  Avg throttle: {lap_metrics.avg_throttle_pct:.1f} %")
    print(f"  Top gear    : {lap_metrics.top_gear}")
    print(f"  Corners     : {lap_metrics.n_corners}")
    print("-" * 65)
    for cm in lap_metrics.corner_metrics:
        print(f"  {cm}")
    print("=" * 65)
