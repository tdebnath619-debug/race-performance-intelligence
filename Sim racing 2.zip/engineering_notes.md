# Engineering Notes — Telemetry Analysis Engine

## Architecture Decisions

### Distance-First Comparison
All lap comparisons are performed on a **common distance grid** rather than a time grid. This correctly handles laps where one driver is faster in some sections: a time-grid alignment would phase-shift the signal and make braking/throttle comparisons meaningless.

### Corner Detection State Machine
The segmentation module uses a lightweight state machine (not a full signal-processing pipeline) because:
- Telemetry sample rates vary (10–200 Hz across platforms)
- A state machine is readable, debuggable, and fast enough for single-lap data
- More sophisticated methods (wavelet, ML) can be added as future modules

### Z-score Spike Removal
Rolling z-score is preferred over global z-score because track features (straights, chicanes) create legitimate bi-modal speed distributions. A global z-score would remove valid data near speed extremes.

### Throttle Ramp Rate
Computed as `Δthrottle / Δtime` over the first 20 samples after apex. A higher ramp rate generally indicates better traction confidence and earlier power delivery — a useful proxy for driver style vs setup balance.

## Known Limitations

| Area | Limitation | Planned Resolution |
|------|------------|-------------------|
| Segmentation | Hairpins with no measurable braking (slow speed entry) may be missed | Add steering-angle detection fallback |
| Comparison | Assumes laps are on the same circuit | Add track fingerprint check |
| Distance | GPS-derived distance accumulates error over lap | Normalise by known lap length in loader |
| Signals | Gear detection unreliable at low RPM | Add gear-change event detection from RPM derivative |

## Integration Points (Future Modules)

```
telemetry.metrics.LapMetrics
    → lap_time_simulator:  feed entry/exit speeds + corner geometry
    → setup_optimizer:     feed brake_pressure_max + throttle_ramp_rate
    → race_strategy_engine: feed fuel consumption + tire_temp signals
```

## Platform CSV Column Mapping

| Internal Name | Assetto Corsa | iRacing | ACC |
|---------------|---------------|---------|-----|
| time | timestamp | elapsed | time_s |
| speed | speed_kmh | car_speed | speed |
| throttle | gas | throttle_input | throttle_pct |
| brake | brake | brake_input | brake_pct |
| gear | gear | current_gear | gear |
| rpm | rpm | engine_rpm | rpm |
| steering | steer | steer_angle | steering_wheel |

## Performance Budget
Target: process a 50 Hz, 120 s lap in < 2 s on a modern laptop.
Current benchmarks (synthetic data, MacBook M2):

| Step | Time |
|------|------|
| Load + validate | ~40 ms |
| Signal cleaning | ~80 ms |
| Corner segmentation | ~120 ms |
| Metrics computation | ~30 ms |
| Lap comparison | ~60 ms |
| **Total** | **~330 ms** |
