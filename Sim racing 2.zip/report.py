"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/report.py

Generate JSON and CSV reports from analysis objects.
"""

import json
import csv
import numpy as np
from pathlib import Path
from typing import Optional
import logging


class _NumpyEncoder(json.JSONEncoder):
    """Make numpy scalars JSON-serialisable."""
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)

logger = logging.getLogger(__name__)


def save_lap_report(
    lap_metrics,                    # LapMetrics
    comparison_report=None,         # ComparisonReport | None
    out_dir: str | Path = "reports",
    stem: str = "lap_analysis",
) -> dict[str, Path]:
    """
    Write analysis results to:
      <out_dir>/<stem>.json    — full structured report
      <out_dir>/<stem>_corners.csv — corner metrics table

    Returns dict of {format: path}.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── Build report dict ─────────────────────────────────────────────────
    report = lap_metrics.to_dict()
    if comparison_report is not None:
        report["comparison"] = comparison_report.to_dict()

    # ── JSON ──────────────────────────────────────────────────────────────
    json_path = out_dir / f"{stem}.json"
    json_path.write_text(json.dumps(report, indent=2, cls=_NumpyEncoder))
    logger.info(f"JSON report saved → {json_path}")

    # ── CSV (corner metrics) ───────────────────────────────────────────────
    csv_path = out_dir / f"{stem}_corners.csv"
    corners  = report.get("corner_metrics", [])
    if corners:
        keys = list(corners[0].keys())
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(corners)
        logger.info(f"CSV report saved → {csv_path}")

    return {"json": json_path, "csv": csv_path}
