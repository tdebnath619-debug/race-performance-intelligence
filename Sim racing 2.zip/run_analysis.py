"""
Race Performance Intelligence System
File: run_analysis.py

End-to-end pipeline demo.
Generates synthetic data → loads → cleans → segments → metrics → compares → report.

Usage
-----
    python run_analysis.py                        # uses synthetic sample data
    python run_analysis.py path/to/telemetry.csv  # uses real telemetry file
"""

import sys
import logging
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
)

# ── Resolve input file ─────────────────────────────────────────────────────────
if len(sys.argv) > 1:
    INPUT_CSV = Path(sys.argv[1])
else:
    # Generate sample data automatically
    from data.raw.generate_sample_telemetry import generate
    INPUT_CSV = generate()

# ── Imports ───────────────────────────────────────────────────────────────────
from telemetry.loader      import load_telemetry, list_laps
from telemetry.cleaner     import clean_telemetry, compute_derivatives, flag_coasting
from telemetry.segmentation import segment_corners, corners_to_dataframe
from telemetry.metrics     import compute_lap_metrics, print_lap_summary
from telemetry.comparison  import compare_laps, plot_comparison
from telemetry.report      import save_lap_report


def main():
    print("\n" + "=" * 65)
    print("  RACE PERFORMANCE INTELLIGENCE SYSTEM — Telemetry Analysis")
    print("=" * 65 + "\n")

    # ── 1. Load ───────────────────────────────────────────────────────────
    df_all = load_telemetry(INPUT_CSV)
    print("\n[Lap summary]")
    print(list_laps(df_all).to_string(index=False))
    print()

    laps = sorted(df_all["lap_number"].unique())
    if len(laps) < 1:
        raise RuntimeError("No laps found in telemetry file.")

    # ── 2. Process each lap ───────────────────────────────────────────────
    results = {}
    for lap_num in laps[:2]:    # process max 2 laps for demo
        print(f"\n{'─' * 55}")
        print(f"  Processing Lap {lap_num}")
        print(f"{'─' * 55}")

        df_lap = df_all[df_all["lap_number"] == lap_num].copy().reset_index(drop=True)

        # Clean
        df_clean = clean_telemetry(df_lap)
        df_clean = compute_derivatives(df_clean)
        df_clean = flag_coasting(df_clean)

        # Segment
        corners, df_tagged = segment_corners(df_clean)
        print(f"\n  Detected {len(corners)} corners.")

        # Metrics
        lap_metrics = compute_lap_metrics(df_tagged, corners, lap_id=lap_num)
        print_lap_summary(lap_metrics)

        results[lap_num] = {
            "df":      df_clean,
            "corners": corners,
            "metrics": lap_metrics,
        }

    # ── 3. Lap comparison (if ≥ 2 laps) ──────────────────────────────────
    if len(results) >= 2:
        lap_ids = list(results.keys())
        lap_a_id, lap_b_id = lap_ids[0], lap_ids[1]
        r_a, r_b = results[lap_a_id], results[lap_b_id]

        print(f"\n{'─' * 55}")
        print(f"  Comparing Lap {lap_a_id} vs Lap {lap_b_id}")
        print(f"{'─' * 55}\n")

        report, cum_delta, common_dist = compare_laps(
            df_a      = r_a["df"],
            df_b      = r_b["df"],
            corners_a = r_a["corners"],
            corners_b = r_b["corners"],
            metrics_a = r_a["metrics"],
            metrics_b = r_b["metrics"],
            lap_a_id  = lap_a_id,
            lap_b_id  = lap_b_id,
        )
        print(f"\n  {report.summary}")
        for cd in report.sector_deltas:
            print(f"    Turn {cd.corner_id:2d} | Δt={cd.time_delta_s:+.3f} s | {cd.narrative}")

        # ── 4. Save comparison chart ──────────────────────────────────────
        plot_path = Path("reports/comparison_chart.png")
        plot_comparison(
            df_a        = r_a["df"],
            df_b        = r_b["df"],
            cum_delta   = cum_delta,
            common_dist = common_dist,
            lap_a_label = f"Lap {lap_a_id}",
            lap_b_label = f"Lap {lap_b_id}",
            out_path    = plot_path,
        )

        # ── 5. Save report ────────────────────────────────────────────────
        paths = save_lap_report(
            lap_metrics        = r_a["metrics"],
            comparison_report  = report,
            out_dir            = "reports",
            stem               = "lap_analysis",
        )
        print(f"\n  Reports written:")
        for fmt, p in paths.items():
            print(f"    [{fmt.upper()}] {p}")

    print("\n" + "=" * 65)
    print("  Analysis complete.")
    print("=" * 65 + "\n")


if __name__ == "__main__":
    main()
