"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/segmentation.py

Corner detection and track segmentation.

Algorithm
---------
A corner is defined by three sequential phases:
  1. BRAKING PHASE    — brake > threshold AND speed decreasing
  2. APEX             — local speed minimum within the braking phase
  3. EXIT PHASE       — throttle increasing after apex until speed recovers

Each detected corner is described by:
  corner_id, entry_distance, apex_distance, exit_distance
  (and corresponding time stamps)
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field, asdict
from typing import Optional
import logging

logger = logging.getLogger(__name__)


# ─── Data structures ─────────────────────────────────────────────────────────

@dataclass
class Corner:
    corner_id:      int
    # distances (m)
    entry_distance: float
    apex_distance:  float
    exit_distance:  float
    # times (s)
    entry_time:     float
    apex_time:      float
    exit_time:      float
    # raw indices into the source DataFrame
    entry_idx:      int
    apex_idx:       int
    exit_idx:       int
    # convenience
    corner_length_m: float = field(init=False)
    corner_time_s:   float = field(init=False)

    def __post_init__(self):
        self.corner_length_m = round(self.exit_distance - self.entry_distance, 1)
        self.corner_time_s   = round(self.exit_time - self.entry_time, 3)

    def to_dict(self) -> dict:
        return asdict(self)


# ─── Main entry point ─────────────────────────────────────────────────────────

def segment_corners(
    df: pd.DataFrame,
    brake_threshold:    float = 0.05,
    speed_drop_kmh:     float = 10.0,
    min_corner_length_m:float = 20.0,
    min_corner_gap_m:   float = 50.0,
    throttle_threshold: float = 0.10,
) -> tuple[list[Corner], pd.DataFrame]:
    """
    Detect corners in a single-lap telemetry DataFrame.

    Parameters
    ----------
    df                  : Cleaned single-lap telemetry DataFrame.
    brake_threshold     : Minimum brake signal (0-1) to mark braking onset.
    speed_drop_kmh      : Minimum speed reduction required to qualify as a corner.
    min_corner_length_m : Corners shorter than this (entry→exit) are discarded.
    min_corner_gap_m    : Minimum distance between the exit of one corner and
                          the entry of the next (merges closely spaced events).
    throttle_threshold  : Throttle level that defines the start of corner exit.

    Returns
    -------
    corners : list[Corner]
    df      : Input DataFrame with added columns:
              phase  ('straight' | 'braking' | 'corner' | 'exit')
              corner_id  (int, NaN on straights)
    """
    df = df.copy()
    df["phase"]     = "straight"
    df["corner_id"] = np.nan

    # ── Pre-compute helpers ────────────────────────────────────────────────
    df = _ensure_derivatives(df)

    corners: list[Corner] = []
    corner_id = 1

    # ── State machine ─────────────────────────────────────────────────────
    in_corner   = False
    entry_idx   = None
    last_exit_distance = -np.inf

    i = 0
    n = len(df)

    while i < n:
        row = df.iloc[i]

        if not in_corner:
            # Detect braking onset
            if _is_braking_onset(df, i, brake_threshold):
                # Confirm speed actually drops meaningfully
                entry_speed = row["speed"]
                entry_idx   = i
                in_corner   = True
                logger.debug(f"Braking onset at dist={row['distance']:.1f} m, "
                              f"speed={entry_speed:.1f} km/h")
        else:
            # Already inside a corner sequence → look for apex
            apex_idx = _find_apex(df, entry_idx, i, lookahead=80)
            if apex_idx is None:
                # No apex found yet — keep scanning
                if i - entry_idx > 300:
                    # Safety: abandon if corner lasts > 300 samples
                    in_corner = False
                i += 1
                continue

            # Find exit: throttle pickup after apex
            exit_idx = _find_exit(df, apex_idx, throttle_threshold, lookahead=150)
            if exit_idx is None:
                exit_idx = min(apex_idx + 80, n - 1)

            # ── Validate corner ────────────────────────────────────────
            entry_row = df.iloc[entry_idx]
            apex_row  = df.iloc[apex_idx]
            exit_row  = df.iloc[exit_idx]

            speed_drop = entry_row["speed"] - apex_row["speed"]
            length_m   = exit_row["distance"] - entry_row["distance"]
            gap_m      = entry_row["distance"] - last_exit_distance

            if (speed_drop >= speed_drop_kmh
                    and length_m >= min_corner_length_m
                    and gap_m >= min_corner_gap_m):

                corner = Corner(
                    corner_id      = corner_id,
                    entry_distance = round(entry_row["distance"], 1),
                    apex_distance  = round(apex_row["distance"],  1),
                    exit_distance  = round(exit_row["distance"],  1),
                    entry_time     = round(entry_row["time"], 3),
                    apex_time      = round(apex_row["time"],  3),
                    exit_time      = round(exit_row["time"],  3),
                    entry_idx      = entry_idx,
                    apex_idx       = apex_idx,
                    exit_idx       = exit_idx,
                )
                corners.append(corner)
                last_exit_distance = corner.exit_distance

                # Tag DataFrame rows
                df.loc[entry_idx:apex_idx,  "phase"]     = "braking"
                df.loc[apex_idx:exit_idx,   "phase"]     = "exit"
                df.loc[apex_idx,             "phase"]     = "corner"
                df.loc[entry_idx:exit_idx,  "corner_id"] = corner_id

                logger.info(
                    f"Corner {corner_id:2d} | "
                    f"entry={corner.entry_distance:6.1f} m | "
                    f"apex={corner.apex_distance:6.1f} m | "
                    f"exit={corner.exit_distance:6.1f} m | "
                    f"Δspeed={speed_drop:.1f} km/h"
                )
                corner_id += 1
                i = exit_idx + 1
            else:
                i = apex_idx + 1

            in_corner = False
            continue

        i += 1

    logger.info(f"Segmentation complete — {len(corners)} corner(s) detected.")
    return corners, df


# ─── Detection helpers ────────────────────────────────────────────────────────

def _ensure_derivatives(df: pd.DataFrame) -> pd.DataFrame:
    """Compute d_speed if not already present."""
    if "d_speed" not in df.columns:
        dt = df["time"].diff().replace(0, np.nan)
        df["d_speed"] = df["speed"].diff() / dt
    return df


def _is_braking_onset(df: pd.DataFrame, i: int, brake_threshold: float) -> bool:
    """
    Heuristic: consider braking onset when brake exceeds threshold
    OR speed is sharply decreasing (covers engine-braking cornering).
    """
    row = df.iloc[i]
    brake_active = (
        "brake" in df.columns and row.get("brake", 0) > brake_threshold
    )
    speed_falling = row.get("d_speed", 0) < -5.0   # km/h per second
    return brake_active or speed_falling


def _find_apex(
    df: pd.DataFrame, start: int, current: int, lookahead: int
) -> Optional[int]:
    """
    Find the local speed minimum in the window [start, start + lookahead].
    Returns None if the minimum is at the edges (i.e. not yet reached).
    """
    end = min(start + lookahead, len(df) - 1)
    window = df["speed"].iloc[start:end]
    if len(window) < 5:
        return None
    min_idx_local = int(window.idxmin())
    # Reject if minimum is at very start or very end of window
    if min_idx_local <= start + 2 or min_idx_local >= end - 2:
        return None
    return min_idx_local


def _find_exit(
    df: pd.DataFrame, apex_idx: int, throttle_threshold: float, lookahead: int
) -> Optional[int]:
    """
    Find the first sample after apex where throttle rises above threshold.
    """
    if "throttle" not in df.columns:
        return None
    end = min(apex_idx + lookahead, len(df) - 1)
    window = df["throttle"].iloc[apex_idx:end]
    above = window[window > throttle_threshold]
    if above.empty:
        return None
    return int(above.index[0])


# ─── Utility ─────────────────────────────────────────────────────────────────

def corners_to_dataframe(corners: list[Corner]) -> pd.DataFrame:
    """Convert a list of Corner objects to a summary DataFrame."""
    return pd.DataFrame([c.to_dict() for c in corners])


def get_corner(corners: list[Corner], corner_id: int) -> Optional[Corner]:
    """Look up a corner by its ID."""
    for c in corners:
        if c.corner_id == corner_id:
            return c
    return None


def extract_corner_slice(
    df: pd.DataFrame, corner: Corner, padding_m: float = 20.0
) -> pd.DataFrame:
    """
    Return the telemetry slice for a given corner including optional padding.
    """
    mask = (
        (df["distance"] >= corner.entry_distance - padding_m) &
        (df["distance"] <= corner.exit_distance  + padding_m)
    )
    return df[mask].reset_index(drop=True)
