"""
Race Performance Intelligence System
Module 1 — Telemetry Analysis Engine
File: telemetry/comparison.py

Compare two laps: time delta, corner-by-corner delta, signal overlays.

Output
------
  ComparisonReport    — structured report object
  Plots               — speed, throttle, brake, lap-delta vs distance
"""

import json
from pathlib import Path
import numpy as np
import pandas as pd
from dataclasses import dataclass, field, asdict
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# Optional plotting — graceful degradation if matplotlib unavailable
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    PLOTTING = True
except ImportError:
    PLOTTING = False
    logger.warning("matplotlib not available — plotting disabled.")

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    PLOTLY = True
except ImportError:
    PLOTLY = False


# ─── Data structures ─────────────────────────────────────────────────────────

@dataclass
class CornerDelta:
    corner_id:          int
    # position on track
    apex_distance_m:    float
    # time delta (positive → lap B is slower at this corner)
    time_delta_s:       float
    entry_speed_delta:  float   # lap_A − lap_B  km/h
    min_speed_delta:    float
    exit_speed_delta:   float
    brake_point_delta_m:float   # positive → lap B brakes later
    throttle_point_delta_m: float
    narrative:          str = ""

    def __post_init__(self):
        self.narrative = self._generate_narrative()

    def _generate_narrative(self) -> str:
        parts = []
        if abs(self.time_delta_s) >= 0.01:
            faster = "Lap A" if self.time_delta_s > 0 else "Lap B"
            parts.append(
                f"{faster} is {abs(self.time_delta_s):.3f} s faster at corner {self.corner_id}."
            )
        if abs(self.entry_speed_delta) >= 2:
            higher = "Lap A" if self.entry_speed_delta > 0 else "Lap B"
            parts.append(
                f"{higher} carries {abs(self.entry_speed_delta):.1f} km/h more entry speed."
            )
        if abs(self.brake_point_delta_m) >= 5:
            later = "Lap A" if self.brake_point_delta_m < 0 else "Lap B"
            parts.append(
                f"{later} brakes {abs(self.brake_point_delta_m):.1f} m later."
            )
        if abs(self.throttle_point_delta_m) >= 5:
            earlier = "Lap A" if self.throttle_point_delta_m > 0 else "Lap B"
            parts.append(
                f"{earlier} picks up throttle {abs(self.throttle_point_delta_m):.1f} m earlier."
            )
        if abs(self.exit_speed_delta) >= 2:
            higher = "Lap A" if self.exit_speed_delta > 0 else "Lap B"
            parts.append(
                f"{higher} exits {abs(self.exit_speed_delta):.1f} km/h faster."
            )
        return " ".join(parts) if parts else "No significant difference at this corner."

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ComparisonReport:
    lap_a_id:           int
    lap_b_id:           int
    total_delta_s:      float          # positive → lap A is faster
    sector_deltas:      list[CornerDelta] = field(default_factory=list)
    summary:            str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["sector_deltas"] = [c.to_dict() for c in self.sector_deltas]
        return d

    def to_json(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2))
        logger.info(f"Comparison report saved → {path}")
        return path


# ─── Main comparison ─────────────────────────────────────────────────────────

def compare_laps(
    df_a: pd.DataFrame,
    df_b: pd.DataFrame,
    corners_a: list,          # list[Corner]
    corners_b: list,          # list[Corner]
    metrics_a=None,           # LapMetrics | None
    metrics_b=None,           # LapMetrics | None
    lap_a_id: int = 0,
    lap_b_id: int = 1,
) -> ComparisonReport:
    """
    Compare two laps and produce a ComparisonReport.

    The comparison is done on a common distance grid so laps of slightly
    different lengths (due to GPS noise) can be aligned.
    """
    # ── Align to common distance grid ─────────────────────────────────────
    common_dist, sig_a, sig_b = _align_on_distance(df_a, df_b)

    # ── Cumulative time delta ──────────────────────────────────────────────
    # Positive delta → lap A is ahead at that point on track
    cum_delta = _cumulative_time_delta(df_a, df_b, common_dist)

    total_delta = round(float(cum_delta[-1]), 3)

    # ── Per-corner deltas ──────────────────────────────────────────────────
    corner_deltas: list[CornerDelta] = []

    # Match corners by closest apex distance
    matched = _match_corners(corners_a, corners_b)

    for c_a, c_b in matched:
        # Time delta at corner exit
        apex_dist = (c_a.apex_distance + c_b.apex_distance) / 2
        delta_at_exit = float(np.interp(c_a.exit_distance, common_dist, cum_delta))

        # Speed deltas (from LapMetrics if available, otherwise from raw df)
        entry_speed_a = _speed_at(df_a, c_a.entry_idx)
        entry_speed_b = _speed_at(df_b, c_b.entry_idx)
        apex_speed_a  = _speed_at(df_a, c_a.apex_idx)
        apex_speed_b  = _speed_at(df_b, c_b.apex_idx)
        exit_speed_a  = _speed_at(df_a, c_a.exit_idx)
        exit_speed_b  = _speed_at(df_b, c_b.exit_idx)

        # Brake / throttle point distance delta
        brake_delta    = c_a.entry_distance    - c_b.entry_distance
        throttle_delta = c_a.apex_distance     - c_b.apex_distance   # crude proxy

        cd = CornerDelta(
            corner_id              = c_a.corner_id,
            apex_distance_m        = round(apex_dist, 1),
            time_delta_s           = round(delta_at_exit, 3),
            entry_speed_delta      = round(entry_speed_a - entry_speed_b, 2),
            min_speed_delta        = round(apex_speed_a  - apex_speed_b,  2),
            exit_speed_delta       = round(exit_speed_a  - exit_speed_b,  2),
            brake_point_delta_m    = round(brake_delta,    1),
            throttle_point_delta_m = round(throttle_delta, 1),
        )
        corner_deltas.append(cd)
        logger.info(f"  {cd.narrative}")

    # ── Summary ───────────────────────────────────────────────────────────
    faster = f"Lap {lap_a_id}" if total_delta > 0 else f"Lap {lap_b_id}"
    summary = (
        f"{faster} is faster by {abs(total_delta):.3f} s overall. "
        f"Compared {len(corner_deltas)} corner(s)."
    )

    report = ComparisonReport(
        lap_a_id      = lap_a_id,
        lap_b_id      = lap_b_id,
        total_delta_s = total_delta,
        sector_deltas = corner_deltas,
        summary       = summary,
    )
    logger.info(summary)
    return report, cum_delta, common_dist


# ─── Alignment helpers ────────────────────────────────────────────────────────

def _align_on_distance(
    df_a: pd.DataFrame,
    df_b: pd.DataFrame,
    n_points: int = 2000,
) -> tuple[np.ndarray, dict, dict]:
    """
    Interpolate both laps onto a common distance grid.
    Returns (common_dist, signals_a, signals_b) where each signals dict maps
    column name → np.ndarray.
    """
    d_min = max(df_a["distance"].min(), df_b["distance"].min())
    d_max = min(df_a["distance"].max(), df_b["distance"].max())
    common_dist = np.linspace(d_min, d_max, n_points)

    signals = {}
    for label, df in [("a", df_a), ("b", df_b)]:
        s = {}
        for col in ("speed", "throttle", "brake", "time"):
            if col in df.columns:
                s[col] = np.interp(common_dist, df["distance"], df[col])
        signals[label] = s

    return common_dist, signals["a"], signals["b"]


def _cumulative_time_delta(
    df_a: pd.DataFrame,
    df_b: pd.DataFrame,
    common_dist: np.ndarray,
) -> np.ndarray:
    """
    Compute cumulative time delta on the common distance grid.
    Uses distance/speed integration: Δt = Δd/v.
    Positive → lap A is faster (ahead in time).
    """
    speed_a = np.interp(common_dist, df_a["distance"], df_a["speed"]) / 3.6  # m/s
    speed_b = np.interp(common_dist, df_b["distance"], df_b["speed"]) / 3.6

    dd   = np.diff(common_dist, prepend=common_dist[0])
    dt_a = np.where(speed_a > 0, dd / speed_a, 0)
    dt_b = np.where(speed_b > 0, dd / speed_b, 0)

    return np.cumsum(dt_b - dt_a)   # positive → lap A faster


def _match_corners(corners_a: list, corners_b: list) -> list[tuple]:
    """Greedily match corners from lap A to lap B by closest apex distance."""
    matched = []
    used_b  = set()
    for c_a in corners_a:
        best_dist = np.inf
        best_b    = None
        for c_b in corners_b:
            if id(c_b) in used_b:
                continue
            d = abs(c_a.apex_distance - c_b.apex_distance)
            if d < best_dist and d < 200:   # max 200 m mismatch
                best_dist = d
                best_b    = c_b
        if best_b is not None:
            matched.append((c_a, best_b))
            used_b.add(id(best_b))
    return matched


def _speed_at(df: pd.DataFrame, idx: int) -> float:
    idx = max(0, min(idx, len(df) - 1))
    return round(float(df.iloc[idx]["speed"]), 2)


# ─── Plotting ─────────────────────────────────────────────────────────────────

def plot_comparison(
    df_a: pd.DataFrame,
    df_b: pd.DataFrame,
    cum_delta: np.ndarray,
    common_dist: np.ndarray,
    lap_a_label: str = "Lap A",
    lap_b_label: str = "Lap B",
    out_path: Optional[str | Path] = None,
    show: bool = False,
) -> Optional[Path]:
    """
    Four-panel matplotlib comparison chart:
      1. Speed vs distance
      2. Throttle vs distance
      3. Brake vs distance
      4. Lap delta vs distance
    """
    if not PLOTTING:
        logger.warning("matplotlib unavailable — skipping plot.")
        return None

    fig = plt.figure(figsize=(16, 10))
    gs  = gridspec.GridSpec(4, 1, hspace=0.07, figure=fig)

    colours = {"a": "#E10600", "b": "#1E6FE0"}   # red, blue

    panels = [
        ("speed",    "Speed (km/h)",    gs[0]),
        ("throttle", "Throttle (0-1)",  gs[1]),
        ("brake",    "Brake (0-1)",     gs[2]),
    ]

    axes = []
    for col, ylabel, gs_pos in panels:
        ax = fig.add_subplot(gs_pos)
        for label, df, colour in [("a", df_a, colours["a"]),
                                   ("b", df_b, colours["b"])]:
            if col in df.columns:
                interp_vals = np.interp(common_dist, df["distance"], df[col])
                ax.plot(common_dist, interp_vals,
                        color=colour, linewidth=0.9,
                        label=lap_a_label if label == "a" else lap_b_label)
        ax.set_ylabel(ylabel, fontsize=8)
        ax.tick_params(labelbottom=False)
        ax.grid(True, alpha=0.25)
        axes.append(ax)

    axes[0].legend(loc="upper right", fontsize=8)

    # Delta panel
    ax_delta = fig.add_subplot(gs[3])
    ax_delta.axhline(0, color="#666", linewidth=0.8, linestyle="--")
    ax_delta.fill_between(common_dist, cum_delta, 0,
                          where=cum_delta > 0, alpha=0.35, color=colours["a"],
                          label=f"{lap_a_label} faster")
    ax_delta.fill_between(common_dist, cum_delta, 0,
                          where=cum_delta < 0, alpha=0.35, color=colours["b"],
                          label=f"{lap_b_label} faster")
    ax_delta.plot(common_dist, cum_delta, color="#222", linewidth=0.9)
    ax_delta.set_xlabel("Distance (m)", fontsize=9)
    ax_delta.set_ylabel("Δ Time (s)", fontsize=8)
    ax_delta.legend(loc="upper right", fontsize=8)
    ax_delta.grid(True, alpha=0.25)

    fig.suptitle(f"Lap Comparison: {lap_a_label} vs {lap_b_label}", fontsize=12, y=0.995)

    if out_path is not None:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, dpi=150, bbox_inches="tight")
        logger.info(f"Comparison chart saved → {out_path}")
    if show:
        plt.show()
    plt.close(fig)
    return Path(out_path) if out_path else None


def plot_corner_detail(
    df_a: pd.DataFrame,
    df_b: pd.DataFrame,
    corner_dist: float,
    window_m: float = 300.0,
    lap_a_label: str = "Lap A",
    lap_b_label: str = "Lap B",
    out_path: Optional[str | Path] = None,
    show: bool = False,
) -> Optional[Path]:
    """
    Zoomed speed / throttle / brake plot around a single corner.
    """
    if not PLOTTING:
        return None

    def _window(df):
        return df[
            (df["distance"] >= corner_dist - window_m / 2) &
            (df["distance"] <= corner_dist + window_m / 2)
        ]

    fig, axes = plt.subplots(3, 1, figsize=(10, 7), sharex=True)
    colours   = ["#E10600", "#1E6FE0"]

    for ax, col, ylabel in zip(axes,
                                ["speed", "throttle", "brake"],
                                ["Speed (km/h)", "Throttle", "Brake"]):
        for i, (label, df, colour) in enumerate([
            (lap_a_label, df_a, colours[0]),
            (lap_b_label, df_b, colours[1]),
        ]):
            w = _window(df)
            if col in w.columns:
                ax.plot(w["distance"], w[col], color=colour,
                        linewidth=1.1, label=label)
        ax.set_ylabel(ylabel, fontsize=8)
        ax.grid(True, alpha=0.25)

    axes[0].legend(fontsize=8)
    axes[0].axvline(corner_dist, color="#999", linestyle=":", linewidth=0.8)
    axes[-1].set_xlabel("Distance (m)", fontsize=9)
    fig.suptitle(f"Corner Detail @ {corner_dist:.0f} m", fontsize=11)
    plt.tight_layout()

    if out_path:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, dpi=150, bbox_inches="tight")
        logger.info(f"Corner detail chart saved → {out_path}")
    if show:
        plt.show()
    plt.close(fig)
    return Path(out_path) if out_path else None
