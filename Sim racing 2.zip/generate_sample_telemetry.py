"""
Race Performance Intelligence System
File: data/raw/generate_sample_telemetry.py

Generate a realistic synthetic 2-lap telemetry CSV for unit testing
and demonstration purposes.  Simulates a simplified 12-corner circuit.
"""

import numpy as np
import pandas as pd
from pathlib import Path

RNG   = np.random.default_rng(42)
HZ    = 50          # 50 Hz sample rate
LAP_M = 4_200       # lap length in metres

# Corner definitions: (entry_dist_m, apex_speed_kmh, exit_speed_kmh, brake_dist_m)
CORNERS = [
    (200,  90, 130, 120),
    (500,  75, 115, 100),
    (800, 110, 145,  80),
    (1100,  65, 105, 130),
    (1400,  95, 130,  90),
    (1700, 120, 155,  70),
    (2000,  80, 120, 110),
    (2350,  55,  95, 140),
    (2700, 105, 140,  85),
    (3000,  70, 110, 115),
    (3350, 130, 160,  60),
    (3750,  85, 125,  95),
]


def _make_speed_profile(noise_scale: float = 0.5) -> tuple[np.ndarray, np.ndarray]:
    """Build a speed (km/h) vs distance (m) profile for one lap."""
    dists  = np.linspace(0, LAP_M, LAP_M * 2)
    speeds = np.full_like(dists, 240.0)   # base straight speed

    for entry_dist, apex_speed, exit_speed, brake_dist in CORNERS:
        # Braking ramp
        b_start = entry_dist
        b_end   = entry_dist + brake_dist
        mask_b  = (dists >= b_start) & (dists < b_end)
        t       = (dists[mask_b] - b_start) / brake_dist
        speeds[mask_b] = np.minimum(speeds[mask_b],
                                     speeds[mask_b][0] * (1 - t) + apex_speed * t
                                     if mask_b.sum() else 240.0)

        # Apex
        apex_w = 60
        mask_a = (dists >= b_end) & (dists < b_end + apex_w)
        speeds[mask_a] = np.minimum(speeds[mask_a], apex_speed)

        # Exit ramp
        ex_start = b_end + apex_w
        ex_end   = min(ex_start + 180, LAP_M)
        mask_e   = (dists >= ex_start) & (dists < ex_end)
        t        = (dists[mask_e] - ex_start) / (ex_end - ex_start)
        speeds[mask_e] = np.minimum(speeds[mask_e],
                                     apex_speed * (1 - t) + exit_speed * t)

    speeds = np.clip(speeds, 50, 290)
    speeds += RNG.normal(0, noise_scale, size=speeds.shape)
    return dists, speeds


def _derive_signals(
    dists: np.ndarray,
    speeds: np.ndarray,
    noise: float = 0.5,
) -> pd.DataFrame:
    n  = len(dists)
    dt = np.gradient(dists) / (np.clip(speeds, 10, 300) / 3.6)
    time_arr = np.cumsum(dt)

    d_speed = np.gradient(speeds, time_arr)

    # Throttle: proportional to positive acceleration
    throttle = np.clip(d_speed / 60 + 0.5 + RNG.normal(0, 0.02, n), 0, 1)

    # Brake: activated when speed is falling fast
    brake = np.where(d_speed < -8, np.clip(-d_speed / 80, 0, 1), 0.0)
    brake += RNG.normal(0, 0.01, n)
    brake  = np.clip(brake, 0, 1)

    # Gear: rough heuristic from speed
    rpm_base = np.where(speeds < 60, 1,
               np.where(speeds < 100, 2,
               np.where(speeds < 140, 3,
               np.where(speeds < 180, 4,
               np.where(speeds < 220, 5, 6)))))
    rpm = rpm_base * 3000 + speeds * 20 + RNG.normal(0, 50, n)
    rpm = np.clip(rpm, 800, 16000)

    steering = np.zeros(n)
    for entry_dist, *_ in CORNERS:
        mask = (dists >= entry_dist) & (dists < entry_dist + 100)
        steering[mask] = RNG.choice([-1, 1]) * np.linspace(0, 0.4, mask.sum())

    return pd.DataFrame({
        "time":     np.round(time_arr, 4),
        "distance": np.round(dists, 2),
        "speed":    np.round(speeds, 2),
        "throttle": np.round(throttle, 4),
        "brake":    np.round(brake, 4),
        "gear":     rpm_base.astype(int),
        "rpm":      np.round(rpm, 0).astype(int),
        "steering": np.round(steering, 4),
    })


def generate(out_path: str | Path = "data/raw/sample_telemetry.csv") -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    frames = []
    t_offset = 0.0

    for lap in range(2):
        noise = 0.5 if lap == 0 else 1.2    # lap 1 cleaner than lap 0
        dists, speeds = _make_speed_profile(noise_scale=noise)
        df_lap = _derive_signals(dists, speeds, noise)
        df_lap["time"]       += t_offset
        df_lap["lap_number"]  = lap
        df_lap["lap_time"]    = df_lap["time"] - t_offset
        t_offset              = float(df_lap["time"].iloc[-1]) + 0.02
        frames.append(df_lap)

    df_full = pd.concat(frames, ignore_index=True)
    df_full.to_csv(out_path, index=False)
    print(f"Sample telemetry written → {out_path}  ({len(df_full)} rows, 2 laps)")
    return out_path


if __name__ == "__main__":
    generate()
