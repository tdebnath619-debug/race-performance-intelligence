"""
Race Performance Intelligence System — Telemetry Package
"""
from .loader      import load_telemetry, list_laps, save_processed
from .cleaner     import clean_telemetry, compute_derivatives, flag_coasting
from .segmentation import segment_corners, corners_to_dataframe, extract_corner_slice
from .metrics     import compute_lap_metrics, print_lap_summary, metrics_to_dataframe
from .comparison  import compare_laps, plot_comparison, plot_corner_detail

__all__ = [
    "load_telemetry", "list_laps", "save_processed",
    "clean_telemetry", "compute_derivatives", "flag_coasting",
    "segment_corners", "corners_to_dataframe", "extract_corner_slice",
    "compute_lap_metrics", "print_lap_summary", "metrics_to_dataframe",
    "compare_laps", "plot_comparison", "plot_corner_detail",
]
