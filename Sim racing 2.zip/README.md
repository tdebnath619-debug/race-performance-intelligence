# Race Performance Intelligence System
### Module 1 — Telemetry Analysis Engine

A modular, production-grade telemetry processing system for sim-racing data analysis.

---

## Quick Start

```bash
# Install dependencies
pip install pandas numpy matplotlib plotly

# Run the full pipeline with synthetic sample data
python run_analysis.py

# Run with your own telemetry file
python run_analysis.py path/to/your/telemetry.csv
```

---

## Repository Structure

```
race-performance-intelligence/
│
├── data/
│   ├── raw/
│   │   └── generate_sample_telemetry.py   ← synthetic data generator
│   └── processed/                          ← auto-created on first run
│
├── telemetry/
│   ├── __init__.py       ← unified package imports
│   ├── loader.py         ← CSV ingestion + column standardisation
│   ├── cleaner.py        ← signal smoothing, spike removal, normalisation
│   ├── segmentation.py   ← corner detection state machine
│   ├── metrics.py        ← per-corner + per-lap performance indicators
│   ├── comparison.py     ← lap-vs-lap delta analysis + charts
│   └── report.py         ← JSON / CSV report export
│
├── reports/              ← auto-created on first run
│   ├── lap_analysis.json
│   ├── lap_analysis_corners.csv
│   └── comparison_chart.png
│
├── docs/
│   └── engineering_notes.md
│
├── run_analysis.py       ← end-to-end pipeline demo
└── README.md
```

---

## Processing Pipeline

```
RAW TELEMETRY CSV
       │
       ▼
 ┌─────────────┐
 │  DATA LOADER │  load_telemetry()  →  standardised DataFrame
 └──────┬──────┘
        │
        ▼
 ┌───────────────┐
 │ SIGNAL CLEANING│  clean_telemetry()  →  spike-free, smoothed df
 └──────┬────────┘
        │
        ▼
 ┌──────────────────┐
 │ TRACK SEGMENTATION│  segment_corners()  →  list[Corner]
 └──────┬───────────┘
        │
        ▼
 ┌──────────────────┐
 │ PERFORMANCE METRICS│  compute_lap_metrics()  →  LapMetrics
 └──────┬───────────┘
        │
        ▼
 ┌───────────────┐
 │ LAP COMPARISON │  compare_laps()  →  ComparisonReport
 └──────┬────────┘
        │
        ▼
 ┌───────────────┐
 │ REPORT OUTPUT │  save_lap_report()  →  JSON + CSV + PNG
 └───────────────┘
```

---

## Module API Reference

### loader.py
```python
df = load_telemetry("telemetry.csv", lap_number=1, resample_hz=50)
laps_summary = list_laps(df)
save_processed(df, "data/processed/")
```

### cleaner.py
```python
df_clean = clean_telemetry(df, spike_zscore_threshold=4.0)
df_clean = compute_derivatives(df_clean)
df_clean = flag_coasting(df_clean)
```

### segmentation.py
```python
corners, df_tagged = segment_corners(df_clean,
                                      brake_threshold=0.05,
                                      speed_drop_kmh=10.0)
corners_df = corners_to_dataframe(corners)
```

### metrics.py
```python
lap_metrics = compute_lap_metrics(df_tagged, corners, lap_id=1)
print_lap_summary(lap_metrics)
metrics_df = metrics_to_dataframe(lap_metrics)
```

### comparison.py
```python
report, cum_delta, common_dist = compare_laps(df_a, df_b,
                                               corners_a, corners_b,
                                               lap_a_id=0, lap_b_id=1)
plot_comparison(df_a, df_b, cum_delta, common_dist,
                out_path="reports/comparison_chart.png")
```

---

## Supported Telemetry Platforms

| Platform | Status | Notes |
|----------|--------|-------|
| Assetto Corsa | ✅ | via `motec_csv` or custom logger |
| iRacing | ✅ | export from iRacing SDK / MoTeC |
| ACC | ✅ | via Shared Memory Bridge |
| Generic CSV | ✅ | requires `time` + `speed` columns |

---

## Future Modules

| Module | Feeds from Telemetry |
|--------|----------------------|
| `lap_time_simulator` | `entry_speed`, `exit_speed`, corner geometry |
| `race_strategy_engine` | `fuel` signal, tire temp trends |
| `setup_optimizer` | `brake_pressure_max`, `throttle_ramp_rate` |

---

## Dependencies

```
pandas >= 2.0
numpy  >= 1.25
matplotlib >= 3.7   (optional — for charts)
plotly >= 5.0       (optional — for interactive charts)
```
